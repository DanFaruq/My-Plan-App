# My Plan — Setup Guide

## How to get this app on your phone (free, 5 minutes)

### Step 1 — Host the files

**Option A: Netlify Drop (easiest)**
1. Go to: https://app.netlify.com/drop
2. Drag the entire "myplan" folder onto the page
3. Wait ~10 seconds — you'll get a free URL like: https://random-name.netlify.app

**Option B: GitHub Pages**
1. Create a free account at github.com
2. Create a new repository named "myplan"
3. Upload all 4 files (index.html, manifest.json, sw.js, icon.svg)
4. Go to Settings → Pages → set Source to "main" branch
5. Your URL will be: https://yourusername.github.io/myplan

---

### Step 2 — Install on your phone

**On Android:**
1. Open the URL in Chrome
2. Tap the 3-dot menu → "Add to Home screen"
3. Or wait for the "Install" banner to appear at the top

**On iPhone/iPad (iOS Safari):**
1. Open the URL in Safari (must be Safari, not Chrome)
2. Tap the Share button (box with arrow at bottom)
3. Scroll down and tap "Add to Home Screen"
4. Tap "Add" — done!

---

### Features
- Works fully offline after first load
- Automatically shows School Day or Weekend schedule
- Checkboxes reset every day at midnight
- Progress bar tracks daily task completion
- Focus tab shows tonight's primary task

---

### Files included
- index.html — the app
- manifest.json — PWA configuration
- sw.js — offline service worker
- icon.svg — app icon
- SETUP.md — this file
